﻿namespace ProjetoTeste.View
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblUsuario = new Label();
            txtUSuario = new TextBox();
            lblSenha = new Label();
            txtSenha = new TextBox();
            lnkRecuperarSenha = new LinkLabel();
            btnAcessar = new Button();
            btnFechar = new Button();
            SuspendLayout();
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Location = new Point(16, 30);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(53, 15);
            lblUsuario.TabIndex = 0;
            lblUsuario.Text = "Usuário: ";
            // 
            // txtUSuario
            // 
            txtUSuario.CharacterCasing = CharacterCasing.Lower;
            txtUSuario.Location = new Point(75, 27);
            txtUSuario.MaxLength = 50;
            txtUSuario.Name = "txtUSuario";
            txtUSuario.Size = new Size(134, 23);
            txtUSuario.TabIndex = 1;
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(22, 82);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(45, 15);
            lblSenha.TabIndex = 2;
            lblSenha.Text = "Senha: ";
            // 
            // txtSenha
            // 
            txtSenha.CharacterCasing = CharacterCasing.Lower;
            txtSenha.Location = new Point(75, 79);
            txtSenha.MaxLength = 50;
            txtSenha.Name = "txtSenha";
            txtSenha.PasswordChar = '*';
            txtSenha.Size = new Size(134, 23);
            txtSenha.TabIndex = 3;
            // 
            // lnkRecuperarSenha
            // 
            lnkRecuperarSenha.AutoSize = true;
            lnkRecuperarSenha.Location = new Point(101, 116);
            lnkRecuperarSenha.Name = "lnkRecuperarSenha";
            lnkRecuperarSenha.Size = new Size(108, 15);
            lnkRecuperarSenha.TabIndex = 4;
            lnkRecuperarSenha.TabStop = true;
            lnkRecuperarSenha.Text = "Esqueceu A Senha?";
            lnkRecuperarSenha.LinkClicked += lnkRecuperarSenha_LinkClicked;
            // 
            // btnAcessar
            // 
            btnAcessar.Location = new Point(53, 140);
            btnAcessar.Name = "btnAcessar";
            btnAcessar.Size = new Size(75, 23);
            btnAcessar.TabIndex = 5;
            btnAcessar.Text = "Acessar";
            btnAcessar.UseVisualStyleBackColor = true;
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(134, 140);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(75, 23);
            btnFechar.TabIndex = 6;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // frmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(223, 175);
            Controls.Add(btnFechar);
            Controls.Add(btnAcessar);
            Controls.Add(lnkRecuperarSenha);
            Controls.Add(txtSenha);
            Controls.Add(lblSenha);
            Controls.Add(txtUSuario);
            Controls.Add(lblUsuario);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmLogin";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            Load += frmLogin_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblUsuario;
        private TextBox txtUSuario;
        private Label lblSenha;
        private TextBox txtSenha;
        private LinkLabel lnkRecuperarSenha;
        private Button btnAcessar;
        private Button btnFechar;
    }
}