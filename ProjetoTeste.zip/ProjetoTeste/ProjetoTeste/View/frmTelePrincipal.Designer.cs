﻿namespace ProjetoTeste.View
{
    partial class frmTelePrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            arquivoToolStripMenuItem = new ToolStripMenuItem();
            sairToolStripMenuItem = new ToolStripMenuItem();
            ajudaToolStripMenuItem = new ToolStripMenuItem();
            sobreOSistemaToolStripMenuItem = new ToolStripMenuItem();
            pnLeft = new Panel();
            btnFuncionarios = new Button();
            btnClientes = new Button();
            panel1 = new Panel();
            textBox1 = new TextBox();
            label1 = new Label();
            menuStrip1.SuspendLayout();
            pnLeft.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { arquivoToolStripMenuItem, ajudaToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(980, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            arquivoToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { sairToolStripMenuItem });
            arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            arquivoToolStripMenuItem.Size = new Size(61, 20);
            arquivoToolStripMenuItem.Text = "Arquivo";
            // 
            // sairToolStripMenuItem
            // 
            sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            sairToolStripMenuItem.ShortcutKeys = Keys.Alt | Keys.F4;
            sairToolStripMenuItem.Size = new Size(135, 22);
            sairToolStripMenuItem.Text = "&Sair";
            // 
            // ajudaToolStripMenuItem
            // 
            ajudaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { sobreOSistemaToolStripMenuItem });
            ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            ajudaToolStripMenuItem.Size = new Size(50, 20);
            ajudaToolStripMenuItem.Text = "Ajuda";
            // 
            // sobreOSistemaToolStripMenuItem
            // 
            sobreOSistemaToolStripMenuItem.Name = "sobreOSistemaToolStripMenuItem";
            sobreOSistemaToolStripMenuItem.Size = new Size(160, 22);
            sobreOSistemaToolStripMenuItem.Text = "Sobre O Sistema";
            sobreOSistemaToolStripMenuItem.Click += sobreOSistemaToolStripMenuItem_Click;
            // 
            // pnLeft
            // 
            pnLeft.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            pnLeft.Controls.Add(btnFuncionarios);
            pnLeft.Controls.Add(btnClientes);
            pnLeft.Location = new Point(20, 36);
            pnLeft.Name = "pnLeft";
            pnLeft.Size = new Size(194, 559);
            pnLeft.TabIndex = 1;
            // 
            // btnFuncionarios
            // 
            btnFuncionarios.Location = new Point(97, 9);
            btnFuncionarios.Name = "btnFuncionarios";
            btnFuncionarios.Size = new Size(88, 72);
            btnFuncionarios.TabIndex = 2;
            btnFuncionarios.Text = "Funcionarios";
            btnFuncionarios.UseVisualStyleBackColor = true;
            btnFuncionarios.Click += btnFuncionarios_Click;
            // 
            // btnClientes
            // 
            btnClientes.Location = new Point(3, 9);
            btnClientes.Name = "btnClientes";
            btnClientes.Size = new Size(88, 72);
            btnClientes.TabIndex = 1;
            btnClientes.Text = "Clientes";
            btnClientes.Click += btnClientes_Click;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(220, 36);
            panel1.Name = "panel1";
            panel1.Size = new Size(748, 100);
            panel1.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            textBox1.Location = new Point(643, 9);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 1;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Location = new Point(597, 12);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 0;
            label1.Text = "Login:";
            // 
            // frmTelePrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(980, 607);
            Controls.Add(panel1);
            Controls.Add(pnLeft);
            Controls.Add(menuStrip1);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MainMenuStrip = menuStrip1;
            Name = "frmTelePrincipal";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tela Principal - Sistema ERP";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            pnLeft.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem arquivoToolStripMenuItem;
        private ToolStripMenuItem sairToolStripMenuItem;
        private ToolStripMenuItem ajudaToolStripMenuItem;
        private ToolStripMenuItem sobreOSistemaToolStripMenuItem;
        private Panel pnLeft;
        private Panel panel1;
        private TextBox textBox1;
        private Label label1;
        private Button btnFuncionarios;
        private Button btnClientes;
    }
}