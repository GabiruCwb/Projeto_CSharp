﻿namespace ProjetoTeste.View
{
    partial class frmFuncionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabCadFuncionario = new TabPage();
            txtNomeCliente = new TextBox();
            lblNomeCliente = new Label();
            tabConsultaFuncionario = new TabPage();
            dtConsultaFuncionario = new DataGridView();
            btnBuscar = new Button();
            txtInformeNome = new TextBox();
            lblInformeNome = new Label();
            ID = new DataGridViewTextBoxColumn();
            NomeFuncionario = new DataGridViewTextBoxColumn();
            CPF = new DataGridViewTextBoxColumn();
            Telefone = new DataGridViewTextBoxColumn();
            label1 = new Label();
            maskedTextBox1 = new MaskedTextBox();
            tabControl1.SuspendLayout();
            tabCadFuncionario.SuspendLayout();
            tabConsultaFuncionario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtConsultaFuncionario).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabCadFuncionario);
            tabControl1.Controls.Add(tabConsultaFuncionario);
            tabControl1.Location = new Point(12, 12);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(568, 333);
            tabControl1.TabIndex = 0;
            // 
            // tabCadFuncionario
            // 
            tabCadFuncionario.Controls.Add(maskedTextBox1);
            tabCadFuncionario.Controls.Add(label1);
            tabCadFuncionario.Controls.Add(txtNomeCliente);
            tabCadFuncionario.Controls.Add(lblNomeCliente);
            tabCadFuncionario.Location = new Point(4, 24);
            tabCadFuncionario.Name = "tabCadFuncionario";
            tabCadFuncionario.Padding = new Padding(3);
            tabCadFuncionario.Size = new Size(560, 305);
            tabCadFuncionario.TabIndex = 0;
            tabCadFuncionario.Text = "Cadastro";
            tabCadFuncionario.UseVisualStyleBackColor = true;
            // 
            // txtNomeCliente
            // 
            txtNomeCliente.Location = new Point(113, 18);
            txtNomeCliente.Name = "txtNomeCliente";
            txtNomeCliente.Size = new Size(439, 23);
            txtNomeCliente.TabIndex = 1;
            // 
            // lblNomeCliente
            // 
            lblNomeCliente.AutoSize = true;
            lblNomeCliente.Location = new Point(6, 21);
            lblNomeCliente.Name = "lblNomeCliente";
            lblNomeCliente.Size = new Size(97, 15);
            lblNomeCliente.TabIndex = 0;
            lblNomeCliente.Text = "Nome do Cliente";
            // 
            // tabConsultaFuncionario
            // 
            tabConsultaFuncionario.Controls.Add(dtConsultaFuncionario);
            tabConsultaFuncionario.Controls.Add(btnBuscar);
            tabConsultaFuncionario.Controls.Add(txtInformeNome);
            tabConsultaFuncionario.Controls.Add(lblInformeNome);
            tabConsultaFuncionario.Location = new Point(4, 24);
            tabConsultaFuncionario.Name = "tabConsultaFuncionario";
            tabConsultaFuncionario.Padding = new Padding(3);
            tabConsultaFuncionario.Size = new Size(560, 305);
            tabConsultaFuncionario.TabIndex = 1;
            tabConsultaFuncionario.Text = "Consulta de Funcionário";
            tabConsultaFuncionario.UseVisualStyleBackColor = true;
            // 
            // dtConsultaFuncionario
            // 
            dtConsultaFuncionario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtConsultaFuncionario.Columns.AddRange(new DataGridViewColumn[] { ID, NomeFuncionario, CPF, Telefone });
            dtConsultaFuncionario.Location = new Point(9, 57);
            dtConsultaFuncionario.Name = "dtConsultaFuncionario";
            dtConsultaFuncionario.RowTemplate.Height = 25;
            dtConsultaFuncionario.Size = new Size(532, 227);
            dtConsultaFuncionario.TabIndex = 5;
            // 
            // btnBuscar
            // 
            btnBuscar.Location = new Point(477, 20);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(75, 23);
            btnBuscar.TabIndex = 4;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += button1_Click;
            // 
            // txtInformeNome
            // 
            txtInformeNome.Location = new Point(113, 20);
            txtInformeNome.Name = "txtInformeNome";
            txtInformeNome.Size = new Size(358, 23);
            txtInformeNome.TabIndex = 3;
            // 
            // lblInformeNome
            // 
            lblInformeNome.AutoSize = true;
            lblInformeNome.Location = new Point(6, 23);
            lblInformeNome.Name = "lblInformeNome";
            lblInformeNome.Size = new Size(97, 15);
            lblInformeNome.TabIndex = 2;
            lblInformeNome.Text = "Informe O Nome";
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.Name = "ID";
            ID.ReadOnly = true;
            ID.Width = 50;
            // 
            // NomeFuncionario
            // 
            NomeFuncionario.HeaderText = "Nome Funcionário";
            NomeFuncionario.MaxInputLength = 100;
            NomeFuncionario.Name = "NomeFuncionario";
            NomeFuncionario.ReadOnly = true;
            NomeFuncionario.Width = 150;
            // 
            // CPF
            // 
            CPF.HeaderText = "CPF";
            CPF.Name = "CPF";
            CPF.ReadOnly = true;
            // 
            // Telefone
            // 
            Telefone.HeaderText = "Telefone";
            Telefone.Name = "Telefone";
            Telefone.ReadOnly = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(14, 55);
            label1.Name = "label1";
            label1.Size = new Size(28, 15);
            label1.TabIndex = 2;
            label1.Text = "CPF";
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(112, 62);
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(100, 23);
            maskedTextBox1.TabIndex = 3;
            // 
            // frmFuncionarios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(580, 357);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmFuncionarios";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Funcionarios - Sistema ERP";
            tabControl1.ResumeLayout(false);
            tabCadFuncionario.ResumeLayout(false);
            tabCadFuncionario.PerformLayout();
            tabConsultaFuncionario.ResumeLayout(false);
            tabConsultaFuncionario.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtConsultaFuncionario).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabCadFuncionario;
        private TabPage tabConsultaFuncionario;
        private TextBox txtNomeCliente;
        private Label lblNomeCliente;
        private TextBox txtInformeNome;
        private Label lblInformeNome;
        private Button btnBuscar;
        private DataGridView dtConsultaFuncionario;
        private Label label1;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn NomeFuncionario;
        private DataGridViewTextBoxColumn CPF;
        private DataGridViewTextBoxColumn Telefone;
        private MaskedTextBox maskedTextBox1;
    }
}