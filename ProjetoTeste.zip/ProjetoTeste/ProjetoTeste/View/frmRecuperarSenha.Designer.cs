﻿namespace ProjetoTeste.View
{
    partial class frmRecuperarSenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtUSuario = new TextBox();
            lblUsuario = new Label();
            SuspendLayout();
            // 
            // txtUSuario
            // 
            txtUSuario.CharacterCasing = CharacterCasing.Lower;
            txtUSuario.Location = new Point(67, 12);
            txtUSuario.MaxLength = 50;
            txtUSuario.Name = "txtUSuario";
            txtUSuario.Size = new Size(134, 23);
            txtUSuario.TabIndex = 3;
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Location = new Point(8, 15);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(53, 15);
            lblUsuario.TabIndex = 2;
            lblUsuario.Text = "Usuário: ";
            // 
            // frmRecuperarSenha
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(217, 450);
            Controls.Add(txtUSuario);
            Controls.Add(lblUsuario);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmRecuperarSenha";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Recuperar Senha";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtUSuario;
        private Label lblUsuario;
    }
}