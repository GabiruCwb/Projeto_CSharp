﻿namespace ProjetoTeste.View
{
    partial class frmSobreSistema
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblVersao = new Label();
            label2 = new Label();
            lblDesenvolvido = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // lblVersao
            // 
            lblVersao.AutoSize = true;
            lblVersao.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            lblVersao.Location = new Point(53, 51);
            lblVersao.Name = "lblVersao";
            lblVersao.Size = new Size(63, 20);
            lblVersao.TabIndex = 0;
            lblVersao.Text = "Versão: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(166, 54);
            label2.Name = "label2";
            label2.Size = new Size(25, 17);
            label2.TabIndex = 1;
            label2.Text = "1.0";
            // 
            // lblDesenvolvido
            // 
            lblDesenvolvido.AutoSize = true;
            lblDesenvolvido.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            lblDesenvolvido.Location = new Point(12, 28);
            lblDesenvolvido.Name = "lblDesenvolvido";
            lblDesenvolvido.Size = new Size(138, 20);
            lblDesenvolvido.TabIndex = 2;
            lblDesenvolvido.Text = "Desenvolvido Por: ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(145, 30);
            label1.Name = "label1";
            label1.Size = new Size(86, 17);
            label1.TabIndex = 3;
            label1.Text = "GAF Sistemas";
            // 
            // frmSobreSistema
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(260, 90);
            Controls.Add(label1);
            Controls.Add(lblDesenvolvido);
            Controls.Add(label2);
            Controls.Add(lblVersao);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmSobreSistema";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sobre O Sistema";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblVersao;
        private Label label2;
        private Label lblDesenvolvido;
        private Label label1;
    }
}