﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoTeste.View
{
    public partial class frmTelePrincipal : Form
    {
        public frmTelePrincipal()
        {
            InitializeComponent();
        }

        private void sobreOSistemaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSobreSistema sob = new frmSobreSistema();
            sob.ShowDialog();
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            frmClientes TelaClientes = new frmClientes();
            TelaClientes.ShowDialog();
        }

        private void btnFuncionarios_Click(object sender, EventArgs e)
        {
            frmFuncionarios TelaFuncionarios = new frmFuncionarios();
            TelaFuncionarios.ShowDialog();
        }
    }
}
